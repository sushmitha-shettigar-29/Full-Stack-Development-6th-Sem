from django.db import models

# Create your models here.
class Student(models.Model): 
    first_name = models.CharField(max_length=50) 
    last_name = models.CharField(max_length=50) 
    email = models.EmailField(unique=True) 
 
    def _str_(self): 
        return f"{self.first_name} {self.last_name}" 
 
class Course(models.Model): 
    name = models.CharField(max_length=100) 
    description = models.TextField() 
 
    def _str_(self): 
        return self.name 
 
class Enrollment(models.Model): 
    student = models.ForeignKey(Student, on_delete=models.CASCADE) 
    course = models.ForeignKey(Course, on_delete=models.CASCADE) 
    date_enrolled = models.DateTimeField(auto_now_add=True) 
 
    class Meta: 
        unique_together = ('student', 'course')
    def _str_(self): 
        return f"{self.student} enrolled in {self.course}" 
    
class Project(models.Model):
    student = models.OneToOneField(Student, on_delete=models.CASCADE)
    topic = models.CharField(max_length=200)
    languages_used = models.CharField(max_length=200)
    duration = models.PositiveIntegerField(help_text="Duration in weeks")
    def _str_(self):
        return f"{self.topic} by {self.student}"