from django.shortcuts import render
from django.utils import timezone

def current_datetime(request):
    current_time = timezone.now()
    context = {'current_time': current_time}
    return render(request, 'current_datetime_app/current_datetime.html', context)
